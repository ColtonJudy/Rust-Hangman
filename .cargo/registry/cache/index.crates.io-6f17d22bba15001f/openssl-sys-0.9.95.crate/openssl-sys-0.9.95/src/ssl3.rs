use libc::*;

pub const SSL3_VERSION: c_int = 0x300;

pub const SSL3_AD_ILLEGAL_PARAMETER: c_int = 47;
